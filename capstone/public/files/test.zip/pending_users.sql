-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 29, 2017 at 11:34 PM
-- Server version: 5.7.19-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cpstn`
--

-- --------------------------------------------------------

--
-- Table structure for table `pending_users`
--

CREATE TABLE `pending_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` bigint(20) NOT NULL,
  `institution` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pending_users`
--

INSERT INTO `pending_users` (`id`, `name`, `email`, `password`, `phone_number`, `institution`, `city`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Dr. Alexis Kuphal DDS', 'effertz.laura@example.org', '$2y$10$FcbdFmmyy8yCBR.1vVW7iuHcz02NnvpD/cG2263ADx8qnmtbIln0O', 7741248351887, 'Spencer-Batz', 'Reyside', 'lfHbBYQuEb', '2017-10-29 07:31:50', '2017-10-29 07:31:50'),
(2, 'Lonzo Sipes', 'wendell.beahan@example.org', '$2y$10$FcbdFmmyy8yCBR.1vVW7iuHcz02NnvpD/cG2263ADx8qnmtbIln0O', 1600056033582, 'Gibson-Effertz', 'Katarinaport', 'kFHCnkHXTA', '2017-10-29 07:31:50', '2017-10-29 07:31:50'),
(3, 'Mrs. Deborah Carroll', 'ebrown@example.com', '$2y$10$FcbdFmmyy8yCBR.1vVW7iuHcz02NnvpD/cG2263ADx8qnmtbIln0O', 9241546300981, 'Bergstrom and Sons', 'West Keith', 'LX8HvyQAmg', '2017-10-29 07:31:50', '2017-10-29 07:31:50'),
(4, 'Elmer Robel', 'watsica.ada@example.org', '$2y$10$FcbdFmmyy8yCBR.1vVW7iuHcz02NnvpD/cG2263ADx8qnmtbIln0O', 2621357914176, 'Terry-Schinner', 'Emmettberg', 'aAG8GGC1tO', '2017-10-29 07:31:50', '2017-10-29 07:31:50'),
(5, 'Shyanne Howell', 'cole.garnet@example.net', '$2y$10$FcbdFmmyy8yCBR.1vVW7iuHcz02NnvpD/cG2263ADx8qnmtbIln0O', 9771959371493, 'Treutel, Franecki and Schuster', 'Lorenfurt', 'yEVZubPRnq', '2017-10-29 07:31:50', '2017-10-29 07:31:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pending_users`
--
ALTER TABLE `pending_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pending_users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pending_users`
--
ALTER TABLE `pending_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
