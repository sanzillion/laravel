-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 29, 2017 at 11:35 PM
-- Server version: 5.7.19-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cpstn`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` bigint(20) NOT NULL,
  `institution` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone_number`, `institution`, `city`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Mitchell Torp', 'johathan76@example.org', '$2y$10$JklBEn8WfxpjQ69bE4pTdudQeBRi6RhzL.FWBwSx0hgrAar3Z7SWi', 6300869558040, 'Bernier and Sons', 'Lake Zacharymouth', 'gmbms1bmzZ', '2017-10-29 07:31:44', '2017-10-29 07:31:44'),
(2, 'Krista Upton', 'hector.greenfelder@example.com', '$2y$10$JklBEn8WfxpjQ69bE4pTdudQeBRi6RhzL.FWBwSx0hgrAar3Z7SWi', 3606021563038, 'Corwin-Schmeler', 'New Justusland', 'p3JZGQeJVr', '2017-10-29 07:31:44', '2017-10-29 07:31:44'),
(3, 'Rickey Nolan', 'golda93@example.org', '$2y$10$JklBEn8WfxpjQ69bE4pTdudQeBRi6RhzL.FWBwSx0hgrAar3Z7SWi', 7461752099336, 'Fay-Bartell', 'East Yessenia', 'zqqNmlC2ID', '2017-10-29 07:31:44', '2017-10-29 07:31:44'),
(4, 'Prof. Ken Schimmel III', 'stuart63@example.net', '$2y$10$JklBEn8WfxpjQ69bE4pTdudQeBRi6RhzL.FWBwSx0hgrAar3Z7SWi', 8821295603239, 'Lang-Dach', 'East Isaiahview', 'z5wso0brl7', '2017-10-29 07:31:44', '2017-10-29 07:31:44'),
(5, 'Miss Madelyn Trantow', 'erdman.soledad@example.net', '$2y$10$JklBEn8WfxpjQ69bE4pTdudQeBRi6RhzL.FWBwSx0hgrAar3Z7SWi', 6253619517288, 'Jast PLC', 'East Gwenville', 'VtPAGx1ETC', '2017-10-29 07:31:44', '2017-10-29 07:31:44'),
(6, 'Sanz Moses', 'sanz@example.com', '$2y$10$AOX3wQ9p0NszJQHhlvyZbOMHn1va1334uiwt.FqTGQZb12qBb78J6', 639074239571, 'SJPIICD', 'Davao', NULL, '2017-10-29 07:32:42', '2017-10-29 07:32:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
