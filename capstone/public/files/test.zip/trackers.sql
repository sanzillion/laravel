-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 29, 2017 at 11:35 PM
-- Server version: 5.7.19-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cpstn`
--

-- --------------------------------------------------------

--
-- Table structure for table `trackers`
--

CREATE TABLE `trackers` (
  `id` int(10) UNSIGNED NOT NULL,
  `user` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trackers`
--

INSERT INTO `trackers` (`id`, `user`, `type`, `action`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, 'admin', 'Admin Logout', 'None', '2017-10-29 05:29:21', '2017-10-29 05:29:21'),
(2, 1, 'admin', 'Admin Login', 'Attempt: 1', '2017-10-29 05:29:43', '2017-10-29 05:29:43'),
(3, 1, 'admin', 'Admin Logout', 'None', '2017-10-29 05:31:47', '2017-10-29 05:31:47'),
(4, 1, 'admin', 'Admin Login', 'Attempt: 1', '2017-10-29 05:32:11', '2017-10-29 05:32:11'),
(5, 1, 'admin', 'Admin Logout', 'None', '2017-10-29 05:32:22', '2017-10-29 05:32:22'),
(6, 1, 'admin', 'Admin Login', 'Attempt: 1', '2017-10-29 06:11:23', '2017-10-29 06:11:23'),
(7, 1, 'admin', 'Admin Login', 'Attempt: 1', '2017-10-29 06:47:47', '2017-10-29 06:47:47'),
(8, 1, 'admin', 'Admin Logout', 'None', '2017-10-29 06:49:45', '2017-10-29 06:49:45'),
(9, 1, 'admin', 'Admin Login', 'Attempt: 1', '2017-10-29 07:08:43', '2017-10-29 07:08:43'),
(10, 1, 'admin', 'Admin Logout', 'None', '2017-10-29 07:08:48', '2017-10-29 07:08:48'),
(11, 1, 'admin', 'Admin Login', 'Attempt: 1', '2017-10-29 07:32:35', '2017-10-29 07:32:35'),
(12, 1, 'admin', 'Created', 'User: id = 6', '2017-10-29 07:32:42', '2017-10-29 07:32:42'),
(13, 1, 'admin', 'Deleted', 'Application: id = 6', '2017-10-29 07:32:43', '2017-10-29 07:32:43'),
(14, 1, 'admin', 'Admin Logout', 'None', '2017-10-29 07:32:54', '2017-10-29 07:32:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `trackers`
--
ALTER TABLE `trackers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `trackers`
--
ALTER TABLE `trackers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
