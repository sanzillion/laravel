-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 29, 2017 at 11:35 PM
-- Server version: 5.7.19-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cpstn`
--

-- --------------------------------------------------------

--
-- Table structure for table `stats`
--

CREATE TABLE `stats` (
  `id` int(10) UNSIGNED NOT NULL,
  `month` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visitor` int(11) NOT NULL,
  `m_log` int(11) NOT NULL,
  `a_log` int(11) NOT NULL,
  `apply` int(11) NOT NULL,
  `approve` int(11) NOT NULL,
  `download` int(11) NOT NULL,
  `sms` int(11) NOT NULL,
  `uptime` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stats`
--

INSERT INTO `stats` (`id`, `month`, `visitor`, `m_log`, `a_log`, `apply`, `approve`, `download`, `sms`, `uptime`, `created_at`, `updated_at`) VALUES
(1, 'January', 10, 5, 25, 15, 20, 10, 5, 10, NULL, NULL),
(2, 'February', 35, 20, 25, 15, 20, 10, 5, 20, NULL, NULL),
(3, 'March', 23, 15, 25, 15, 20, 10, 5, 25, NULL, NULL),
(4, 'April', 58, 45, 25, 15, 20, 10, 5, 80, NULL, NULL),
(5, 'May', 65, 39, 25, 15, 20, 10, 5, 67, NULL, NULL),
(6, 'June', 77, 65, 25, 15, 20, 10, 5, 34, NULL, NULL),
(7, 'July', 43, 23, 25, 15, 20, 10, 5, 54, NULL, NULL),
(8, 'August', 56, 38, 25, 15, 20, 10, 5, 22, NULL, NULL),
(9, 'September', 90, 60, 25, 15, 20, 10, 5, 20, NULL, NULL),
(10, 'October', 150, 45, 31, 16, 21, 10, 5, 125, NULL, '2017-10-29 07:32:42'),
(11, 'November', 67, 54, 25, 15, 20, 10, 5, 93, NULL, NULL),
(12, 'December', 74, 66, 25, 15, 20, 10, 5, 77, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stats`
--
ALTER TABLE `stats`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stats`
--
ALTER TABLE `stats`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
