-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 29, 2017 at 11:34 PM
-- Server version: 5.7.19-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cpstn`
--

-- --------------------------------------------------------

--
-- Table structure for table `pending_posts`
--

CREATE TABLE `pending_posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cover_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pending_posts`
--

INSERT INTO `pending_posts` (`id`, `user_id`, `title`, `body`, `cover_img`, `created_at`, `updated_at`) VALUES
(1, 5, 'Mollitia praesentium natus modi sed soluta iusto.', 'Consequatur aut omnis eum laborum. Harum voluptatem rem architecto numquam et voluptatem. Optio natus repellat asperiores sit natus. Sed fuga ab dolorem.<br><br>Repellat blanditiis esse quos labore. Facere occaecati minus minus qui sit consectetur molestias. Iure cum commodi voluptatum. Qui optio molestias soluta ab. Fugit et quidem tenetur quis vitae non ut eveniet. Dignissimos sit eius fuga laboriosam. Pariatur delectus quaerat voluptates incidunt aperiam quod dolor. Consectetur est enim et alias et. Aut iste inventore quo dolore deleniti dignissimos vero. Dicta consectetur autem quod sapiente minus. Quia beatae praesentium repellat iure rerum est dolore. Facilis fugiat quia reprehenderit quia ut blanditiis nostrum. Animi labore aliquid neque omnis. Sed alias quidem aspernatur voluptate. Iste veniam velit facilis est et qui. Veritatis dolores eveniet earum rerum non. Minus exercitationem debitis voluptate ut dolore. Ipsum ducimus tempora quod laudantium. Autem nobis quas beatae est. Ipsam magni doloribus et doloremque consequatur rem. Et aut voluptas atque id qui ut.<br><br>Magnam et alias non sit saepe odio. Dolor nobis velit deleniti fugiat. Modi ad atque voluptate non doloremque.', NULL, '2017-10-29 07:31:54', '2017-10-29 07:31:54'),
(2, 4, 'Enim incidunt non neque dolorem id expedita commodi et.', 'Consequuntur vel tempore consectetur. Qui nobis possimus accusamus dicta dolorem.<br><br>Sed dicta rerum aut dolor quia. Ut quod ut velit aut et. Ullam labore at voluptatibus alias sit molestiae nostrum. Accusamus eum architecto non assumenda. Dolor iste a necessitatibus tempora. Alias modi nostrum est est sed. Voluptatibus et laudantium pariatur cupiditate suscipit quos mollitia. Modi vel magnam vitae soluta molestiae. Omnis eos accusamus adipisci eaque. Aliquid atque accusantium soluta repellendus ut nulla laboriosam beatae. Omnis deleniti modi rem repellat quia labore magni non. Eos aut voluptatum placeat sed quibusdam. Ad reiciendis natus facilis voluptatibus nobis provident ipsam. Repellat laborum eveniet vel delectus qui voluptatem minima. Molestiae et et dolores et voluptatem sunt. Harum aperiam quis deleniti. Sit voluptas minima ut. Quae tenetur voluptatem et dolorem. Dolore facilis reprehenderit ut rerum suscipit est recusandae voluptatum. Voluptate deserunt dolor non consequatur quia placeat.<br><br>Qui cum dolor perferendis aut. Omnis dolore ut itaque et sed eius molestiae odio. Ab illo reiciendis eos eaque nemo. Dicta optio reiciendis cum asperiores rerum aspernatur quibusdam.', NULL, '2017-10-29 07:31:54', '2017-10-29 07:31:54'),
(3, 1, 'Eveniet a quasi nisi ad molestiae quisquam provident non.', 'Nemo cum et et. Cum sit impedit facere illum. Et ut nulla odio repellat cupiditate corrupti est.<br><br>Veniam molestiae laudantium dolores nostrum quia velit eaque porro. Tenetur adipisci voluptas voluptatum aperiam. Nihil laborum minus consequatur similique saepe omnis corporis. Ex nihil earum ut neque et autem. A aspernatur qui laudantium ex. Et est saepe non praesentium qui veniam consequatur distinctio. Eligendi placeat deserunt beatae et et et. Id voluptatem facere ipsum architecto sed odio dolorum. Esse voluptates omnis incidunt eos dignissimos eaque. Vitae repellat aut quo atque vel qui corrupti. Libero aut rerum culpa deleniti non assumenda. Dolorum iure nam tempora molestiae. Autem sapiente dolorem quam rerum eum in. Reiciendis omnis ab quibusdam quod ut. Et temporibus aliquid odit facilis autem. Perferendis et labore rerum aut occaecati dignissimos. Aut ipsam voluptatem in. Quaerat rerum enim quam quidem animi tempora. Aut natus voluptas et accusamus. Velit at in eveniet voluptatum rerum.<br><br>Quis quam quod labore ea quasi nemo velit. Dolorem vitae eos quia sint nostrum possimus dolor. Nostrum sint fugit voluptatem at earum quibusdam.', NULL, '2017-10-29 07:31:54', '2017-10-29 07:31:54'),
(4, 1, 'Harum et neque ratione consequatur architecto.', 'Dolorem aliquid error et molestiae autem officia. Sed aliquid earum quo aliquid rerum labore. Magnam aliquid impedit magni quia voluptatem.<br><br>Laudantium qui magni id vero dicta ut. Nostrum doloribus sint qui non in. Sit non dignissimos ea rerum porro dicta. Fuga ut labore quasi. Est incidunt ut et aut aliquam excepturi officia. Non itaque non consequatur iusto voluptates. A ut laudantium dolor quam deleniti sit. Necessitatibus delectus quod dolore mollitia libero dolore voluptatum. Doloremque et perferendis vel sunt perferendis omnis. Dolore accusantium magnam libero fugit. Quia accusantium dignissimos et autem ab eligendi eaque. Id sed adipisci suscipit cum eligendi. Fuga reprehenderit reiciendis consectetur dolor aut fuga omnis. Unde sed ducimus amet rerum aliquam. Repudiandae rem incidunt voluptatem non et nostrum quaerat. Nesciunt est eum in veniam nisi ut quibusdam. Explicabo quis a ut nulla ut ipsum iste. Omnis eum itaque et a exercitationem voluptatem pariatur voluptate. Vitae iusto quasi nisi enim hic numquam error. Quaerat occaecati cum voluptatem perferendis mollitia vitae.<br><br>Blanditiis esse nihil corrupti architecto soluta necessitatibus. Ea et dolor est dolorum sed molestiae. Ipsam consequatur sequi aut nam. Et dolores mollitia rerum.', NULL, '2017-10-29 07:31:54', '2017-10-29 07:31:54'),
(5, 2, 'In dignissimos qui et distinctio qui.', 'Necessitatibus mollitia et hic libero quisquam nisi. Qui consectetur mollitia facilis in. Rerum iste voluptatem asperiores dolores autem eos. Officia incidunt sapiente dolores rem ea architecto.<br><br>Non eaque sed aut nam velit aut dicta officiis. Voluptates exercitationem blanditiis itaque itaque eligendi. Voluptatem ut aut rerum et officia. Sapiente dolores vero autem vel quaerat fugit laborum. Nihil officia consequatur natus voluptatem. Omnis ut consequatur laborum velit culpa et. Aperiam iusto odit autem non rerum quia perferendis. Sed quia quia architecto ut dignissimos aperiam. Doloremque dolor aut culpa nihil culpa. Soluta illum alias tenetur. Excepturi corrupti saepe quidem eaque omnis velit placeat. Est autem molestiae illum nulla dolorem. Id nam sit natus quos. Nihil itaque aliquid facilis eos unde. Incidunt commodi perspiciatis nihil et. Ea ex delectus debitis a dolores facilis repudiandae. Et a aut in. Ipsa possimus modi perferendis nisi voluptate quibusdam quos. Quas vitae perspiciatis saepe eius fuga. Iste qui vitae consectetur perspiciatis. Libero nobis sint natus cumque sed. Nesciunt et voluptatum excepturi ut est aspernatur itaque.<br><br>Deleniti et molestiae atque doloribus. Maiores necessitatibus quia doloribus neque eum atque. Est iure temporibus enim est molestias et nobis est. Earum autem suscipit ratione provident.', NULL, '2017-10-29 07:31:54', '2017-10-29 07:31:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pending_posts`
--
ALTER TABLE `pending_posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pending_posts`
--
ALTER TABLE `pending_posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
