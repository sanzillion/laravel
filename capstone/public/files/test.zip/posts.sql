-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 29, 2017 at 11:34 PM
-- Server version: 5.7.19-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cpstn`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cover_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `title`, `body`, `cover_img`, `created_at`, `updated_at`) VALUES
(1, 6, 'Exercitationem consequatur sit eius architecto pariatur deleniti.', 'Qui quis exercitationem temporibus sequi eos non. Unde repellat aut a odit hic nulla in voluptatem. Enim ex omnis dolor natus dolores quas.<br><br>Eos ex quia officiis eveniet natus. Pariatur aspernatur deserunt enim accusantium. Laudantium beatae nisi omnis soluta. Non magni et in. Qui voluptate accusamus vero dignissimos dolore pariatur et. Ut at fuga dolorum recusandae praesentium deserunt ducimus. Provident sapiente error velit perspiciatis. Voluptate eveniet tempora a magnam recusandae. Tenetur sequi odit praesentium omnis consectetur aut et. Dignissimos quam quae eum odit possimus incidunt. Earum odit sunt magnam. Odit optio magni deserunt ab voluptatem minus alias provident. Velit eius eos adipisci unde pariatur repellendus. Minus dolorem aut minus sit consequatur nam accusamus laboriosam. Dolorem dolorem sunt ipsa cumque. Accusantium nostrum debitis dolores reprehenderit. Non est sed sequi inventore voluptatem id mollitia soluta. Unde rerum beatae autem dignissimos. Quas rerum aut debitis adipisci commodi quam consequatur. Dolor magni possimus laborum non nihil sapiente et.<br><br>In iste consectetur ducimus dolorem molestiae dolor. Aut placeat et optio inventore. Voluptatem eveniet dolorem totam impedit.', NULL, '2017-10-29 07:33:51', '2017-10-29 07:33:51'),
(2, 1, 'Ad impedit vel optio pariatur.', 'Voluptate rem quia velit explicabo qui. Qui vero deleniti laborum a animi. Sed quia est quia pariatur doloremque accusantium.<br><br>Culpa itaque voluptate et hic. Dolor ut quos ut laudantium rerum quam eveniet. In voluptates mollitia possimus ea. Numquam ullam ad quisquam quae. Et corporis dolorem iusto vero sit ipsam officia. Eius aut assumenda molestiae ipsam sed. Id laborum minima perspiciatis id. Sed corrupti expedita quia. Voluptatem fuga quasi tempore consequatur voluptates. Dolores aut tenetur qui repudiandae et doloremque et atque. Ut veritatis nesciunt praesentium in deleniti id. Architecto et fuga quis quas est vel consectetur. Consequatur illo qui est ut. Esse corrupti saepe et expedita impedit. Sunt a officiis maxime eos quasi dolorem. Aut quia qui eos numquam asperiores perspiciatis illum. Minima sunt nostrum amet ut dolore. Excepturi sed omnis suscipit eveniet. Quia quam deleniti dicta incidunt perferendis exercitationem. Rerum saepe error quod consectetur. Reprehenderit culpa corrupti odit accusantium qui voluptatem ea.<br><br>Et quod voluptatibus aperiam dolores veniam. Et ad culpa voluptatem eos quis est. Error praesentium doloribus dolorum sed repellendus.', NULL, '2017-10-29 07:33:51', '2017-10-29 07:33:51'),
(3, 4, 'Molestias corrupti qui ut veniam modi blanditiis et quisquam.', 'Neque ab debitis sequi vel voluptatem aut. Minima explicabo culpa quia dolores. Omnis omnis porro id vero eos. Et et nostrum tempora tenetur hic modi.<br><br>Est iusto molestias ex minima ut est ad. Repudiandae omnis non ut rerum fugit porro. Placeat totam dolores esse eos quasi accusantium sunt. Similique vel eos minus aut numquam quia. Mollitia soluta magnam sed animi quia magnam. Recusandae nihil est consequuntur assumenda vel id. Repellat perferendis reprehenderit earum dolorum consequatur unde. Quas quis sint qui voluptate. Explicabo dignissimos laudantium pariatur veniam architecto. Ipsum voluptate aut molestias ducimus necessitatibus. Iusto molestias vel incidunt minima est autem. Porro aut accusamus a est esse provident. Non vel alias aut iusto ut est et. Suscipit ipsam aut assumenda voluptatem. Excepturi facere et amet aliquid qui illum. Tempore omnis id id iste id aliquid odit. Libero omnis eum dolorem corrupti non. Sit molestias totam inventore autem ut illo. Ut temporibus possimus sit et repudiandae. Consequatur aut rerum deleniti est asperiores nostrum molestias.<br><br>Et a et odio non libero. Beatae molestiae id non tenetur sunt. Corporis molestias facere aliquam saepe et et blanditiis. Laboriosam quibusdam reprehenderit architecto consequatur blanditiis consequatur sequi.', NULL, '2017-10-29 07:33:51', '2017-10-29 07:33:51'),
(4, 4, 'Qui et asperiores modi sit excepturi blanditiis.', 'Sed nihil dolores est repudiandae modi amet. Maxime minus architecto quasi distinctio. Ducimus cupiditate labore sit magnam.<br><br>Unde qui cumque ratione ipsam error dolore. Et modi a reiciendis. Rerum minus vel qui laborum unde facere libero similique. Et in similique ipsam qui id. Et voluptatem sunt molestiae aperiam vitae accusamus ducimus. Explicabo commodi minus ipsa minus dolor dolorem. Eos quia asperiores quis fugiat. Dolor sed repellendus explicabo quos delectus est. Id dignissimos modi sint rerum ab. Laudantium aut consequatur sequi incidunt. In repellendus molestiae maxime. Atque soluta sequi asperiores est ipsam fugit. Et eligendi quia veniam pariatur. Commodi ea nobis et ipsa. Esse aliquid deleniti omnis adipisci odit. Rem et sint et facere ullam officiis. Non sunt corrupti harum nesciunt. Ut voluptatem ex ducimus assumenda expedita dolore. Et ut enim architecto. Tempora voluptatem qui aut sapiente omnis. Enim delectus nemo earum. Nihil molestiae aspernatur quaerat. Veritatis ipsam nisi nisi dolores. Dolorem nobis dolorum nostrum nobis voluptatem. Quia assumenda numquam quod velit qui.<br><br>Et aliquam non atque non enim error cumque. Accusamus vel voluptatem tempora dolor et recusandae nihil. Autem magni amet sapiente dolorem.', NULL, '2017-10-29 07:33:51', '2017-10-29 07:33:51'),
(5, 6, 'Rerum maxime ex qui quae et temporibus aperiam.', 'Id cumque aut eius dolore et in. Fuga itaque id officia est aperiam sit. Corporis ducimus adipisci rem facere et ut esse. Et sed saepe expedita ut et.<br><br>Unde voluptatum omnis accusamus. Eligendi repellat labore eum commodi. Nisi fuga deserunt quae dolores qui aliquid. Laudantium fuga dolore expedita enim repellat minima. Et atque quod qui odio id. Aut non aut quasi beatae. Repellendus tempora nobis dolorem architecto itaque eveniet quis. In in vel maxime beatae debitis ducimus. Reiciendis cum sit et harum corrupti eos necessitatibus est. Consequuntur magni minus laudantium vitae illo qui. Eveniet quasi expedita odio. Natus laborum est et voluptas impedit reprehenderit eum. Numquam expedita consequatur deserunt et laudantium. Voluptatem fugiat mollitia recusandae qui a. Officia omnis voluptatum quo sint reprehenderit consequatur assumenda sint. Facilis voluptates explicabo ipsum facilis possimus. Esse occaecati molestias quis consequatur qui. Sit atque ullam corporis et consequatur. Repudiandae molestiae sit quasi nulla repellendus cupiditate ipsam.<br><br>Hic mollitia ut est ipsa esse. Dolorem sequi debitis velit. Corrupti libero autem vel quo cum sint aut sint.', NULL, '2017-10-29 07:33:51', '2017-10-29 07:33:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
