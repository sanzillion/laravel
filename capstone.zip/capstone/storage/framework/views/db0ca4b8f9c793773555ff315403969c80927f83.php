<?php $__env->startSection('content'); ?>

	<header class="page-header">
		<div class="container-fluid">
			<h2 class="no-margin-bottom">General Admin Dashboard</h2>
		</div>
	</header>

	<?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="row incon">

		<div class="col-md-12 col-sm-12">
			<div class="card">

			<div class="container-fluid no-margin">
				<div class="row pad-top">
					<div class="col-md-12 col-sm-12">
						<h2><i class="fa fa-check-square-o"></i>&nbsp Pending Approval</h2>
					</div>
				</div> 
			</div>
			
			<table class="table table-sm pendingTable">
				  <thead class="thead-inverse">
				    <tr>
				      <th>#</th>
				      <th>Name</th>
				      <th>Email</th>
				      <th>Phone</th>
				      <th>Institution</th>
				      <th>City</th>
				      <th>Options</th>
				    </tr>
				  </thead>
			  <tbody>
				  	<?php if(count($pendings) > 0): ?>
				  	<?php $__currentLoopData = $pendings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    <tr>
					      <th scope="row"><?php echo e($pending->id); ?></th>
					      <td><?php echo e($pending->name); ?></td>
					      <td><?php echo e($pending->email); ?></td>
					      <td><?php echo e($pending->phone_number); ?></td>
					      <td><?php echo e($pending->institution); ?></td>
					      <td><?php echo e($pending->city); ?></td>
					      <td>

					      	<a class="btn btn-success btn-sm float-left accept" style="margin-right: 5px;" href="/register/<?php echo e($pending->id); ?>">
					      		<i class="fa fa-thumbs-up"></i>
					      	</a>

					      	<?php echo e(Form::open(['action' => ['PendingUserController@destroy', $pending->id], 'method' => 'POST', 'class' => 'float-left'])); ?>

								<?php echo e(Form::hidden('_method', 'DELETE')); ?>

								<?php echo e(Form::button('<i class="fa fa-times"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-sm'])); ?>

							<?php echo e(Form::close()); ?>


					      </td>
					    </tr>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    <?php else: ?>
				    	<tr>
				    		<th colspan="7"></th>
				    	</tr>
				    	<tr>
				    		<th colspan="7" class="text-center">
				    			<h3>No entry</h3>
				    		</th>
				    	</tr>
				    <?php endif; ?>
				  </tbody>
			</table>
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<?php echo e($pendings->render()); ?>

					</div>
				</div>
			</div>

			</div>	
		</div>

		<div class="col-md-12 col-sm-12">
			<div class="card">

				<div class="container-fluid no-margin">
					<div class="row pad-top">
						<div class="col-md-6">
							<h2><i class="fa fa-users"></i>&nbsp Manage Users &nbsp
								<?php if(auth()->user()->isMaster()): ?>
									<button type="button" class="btn btn-danger btn-sm deleteAllUser">
									  <i class="fa fa-exclamation-triangle icon"></i>
									</button>
								<?php endif; ?>
							</h2>
						</div>
						<div class="col-md-6">
							<div class="form-group float-right">
							  <div class="input-group mb-2 mr-sm-2 mb-sm-0" style="height: 25px;">
							    <div class="input-group-addon"><i class="fa fa-search" style="font-size: 10px;"></i></div>
							    <input type="text" class="form-control form-control-sm searchUser" placeholder="search">
							  </div>
							</div>
						</div>
					</div>
				</div>
			
			<table class="table table-sm userTable">
			  <thead class="thead-inverse">
			    <tr>
			      <th>#</th>
			      <th>Name</th>
			      <th>Email</th>
			      <th>Phone</th>
			      <th>Institution</th>
			      <th>City</th>
			      <th>Options</th>
			    </tr>
			  </thead>
			  <tbody class="tbody user">
			  
			  </tbody>
			</table>
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12 col-sm-12 text-center">
						<button class="btn btn-default btn-sm back">
							<i class="fa fa-backward"></i>&nbsp Previous
						</button>
						<button class="btn btn-default btn-sm for">
							Next &nbsp<i class="fa fa-forward"></i>
						</button>
						
					</div>
				</div>
			</div>

			</div>	
		</div>

	</div>

	<?php $__env->startComponent('layouts.dashboard.modal'); ?>
		<?php $__env->slot('id'); ?>
			editUserModal
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('title'); ?>
			<div class="text-info text-lg">
				<i class="fa fa-pencil-square-o"></i>&nbsp Update User
			</div>
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('modalBody'); ?>	
		<div class="row">
			<div class="col-md-10 offset-md-1">

	        <?php echo e(Form::open(['action' => ['UserController@update', ''], 'method' => 'POST', 'id' => 'adminForm'])); ?>

	  			<?php echo e(Form::hidden('_method', 'PATCH')); ?>


	        <div class="form-group row">
	          <label for="name" class="col-2 col-form-label">Name:</label>
	          <div class="col-10">
	  			   <?php echo e(Form::text('name', '', ['id' => 'name', 'class' => 'form-control form-control-sm'])); ?>

	          </div>
	        </div>

	        <div class="form-group row">
	          <label for="email" class="col-2 col-form-label">Email:</label>
	          <div class="col-10">
	            <?php echo e(Form::text('email', '', ['id' => 'email', 'class' => 'form-control form-control-sm'])); ?>  
	          </div>
	        </div>

	        <div class="form-group row">
	          <label for="phone" class="col-2 col-form-label">Phone:</label>
	          <div class="col-10">
	            <?php echo e(Form::text('phone_number', '', ['id' => 'phone', 'class' => 'form-control form-control-sm'])); ?>

	          </div>
	        </div>   

	        <div class="form-group row">
	          <label for="institution" class="col-2 col-form-label">Org:</label>
	          <div class="col-10">
	            <?php echo e(Form::text('institution', '', ['id' => 'institution', 'class' => 'form-control form-control-sm'])); ?>

	          </div>
	        </div>   

	        <div class="form-group row">
	          <label for="city" class="col-2 col-form-label">City:</label>
	          <div class="col-10">
	            <?php echo e(Form::text('city', '', ['id' => 'city', 'class' => 'form-control form-control-sm'])); ?>

	          </div>
	        </div>   

			</div>
		</div>
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('modalFooter'); ?>
			<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        	<?php echo e(Form::submit('Save Changes', ['class' => 'btn btn-info'])); ?>

		      <?php echo e(Form::close()); ?>

		<?php $__env->endSlot(); ?>
	<?php echo $__env->renderComponent(); ?>
	
	<?php $__env->startComponent('layouts.dashboard.sm-modal'); ?>
		<?php $__env->slot('id'); ?>
			deleteAllUser
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('title'); ?>
			<i class="fa fa-asterisk text-danger"></i> Proceed with caution!
			Do you want to delete ALL Users? Are you sure?
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('modalBody'); ?>	
			<div class="row">
				<div class="col-md-12 col-sm-12">
					<form action="/user/delete" method="POST">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<button class="btn btn-danger" type="submit">Yes</button>
						<button type="button" class="btn btn-secondary no" data-dismiss="modal">No</button>
					</form>
				</div>
			</div>
	      	
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('modalFooter'); ?>
		<?php $__env->endSlot(); ?>
	<?php echo $__env->renderComponent(); ?>
	
	<?php $__env->startComponent('layouts.dashboard.sm-modal'); ?>
		<?php $__env->slot('id'); ?>
			deleteUser
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('title'); ?>
			<i class="fa fa-asterisk text-danger"></i> You are about to delete an User. Are you sure?
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('modalBody'); ?>	
			<div class="row">
				<div class="col-md-12 col-sm-12">
					<?php echo e(Form::open(['action' => ['UserController@destroy', ''], 'method' => 'POST', 'class' => 'float-left', 'id' => 'userDelete'])); ?>

						<?php echo e(Form::hidden('_method', 'DELETE')); ?>

						<?php echo e(Form::button('Yes', ['type' => 'submit', 'class' => 'btn btn-danger'])); ?>

						<button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
					<?php echo e(Form::close()); ?>

				</div>
			</div>
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('modalFooter'); ?>
		<?php $__env->endSlot(); ?>
	<?php echo $__env->renderComponent(); ?>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script src="<?php echo e(asset('js/master.js')); ?>"></script>
	<script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>