<!DOCTYPE html>
<html lang="en">

  <?php echo $__env->make('layouts.dashboard.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <body>
  
  <div class="page home-page">
	   <?php echo $__env->make('layouts.dashboard.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     <?php if($flash = session('message')): ?>
      <div id="flash-message" class="alert alert-success" role="alert">
        <?php echo e($flash); ?>

      </div>
     <?php endif; ?>
     <div class="page-content d-flex align-items-stretch">
       <?php echo $__env->make('layouts.dashboard.sidenav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       <div class="content-inner">
         <?php echo $__env->yieldContent('content'); ?>
       </div>
       
       
     </div>
  </div>

  <?php echo $__env->make('layouts.dashboard.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldContent('scripts'); ?>

  </body>
</html>
