<!-- Bootstrap core JavaScript -->
<script src="<?php echo e(asset('js/landing/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/landing/jquery/myjquery.js')); ?>"></script>
<script src="<?php echo e(asset('js/landing/popper/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/landing/bootstrap/js/bootstrap.min.js')); ?>"></script>

<script>
	<?php if(session('page')): ?>
		var session = <?php
			echo "'".session('page')."'";
		?>
	<?php endif; ?>

	$(document).ready(function(){
		$('.sidebar li').removeClass('active');
	  	$('.'+session).addClass('active');
	})

</script>