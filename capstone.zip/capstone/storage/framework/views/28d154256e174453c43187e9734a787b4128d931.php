<?php $__env->startSection('content'); ?>

	<h1><?php echo e($post->title); ?></h1>

	<p class="blog-post-meta"><strong><?php echo e($post->user->name); ?> </strong> on <?php echo e($post->created_at->toFormattedDateString()); ?></p>

	<div class="text-justify"><?php echo $post->body; ?></div>
		
	<br>

	<?php if(count($post->tags)): ?>
		<ul>
			<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="float-right" style="margin-left: 10px; list-style: none;">
					<a href="/posts/tags/<?php echo e($tag->name); ?>">
						<?php echo e($tag->name); ?>

					</a>
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul><br>
	<?php endif; ?>

	<?php if(Auth::check()): ?>
		<?php if(Auth::user()->id == $post->user->id): ?>
		<?php echo e(Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'float-right'])); ?>

			<?php echo e(Form::hidden('_method', 'DELETE')); ?>

			<?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

		<?php echo e(Form::close()); ?>


		<div class="float-left">
			<a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-success" style="margin-right: 10px;">Edit</a>
		</div>
		<?php endif; ?>
	<?php endif; ?>

	<br>

	<div class="comments">
		<ul class="list-group">
		<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="list-group-item">
				<div class="col-md-9">
					<strong>
					<?php echo e($comment->user->name); ?>&nbsp 
					</strong>
					<?php echo e($comment->created_at->diffForHumans()); ?>:
					<br>
					<?php echo e($comment->body); ?>

				</div>
				<div class="col-md-3">
					<a href="" class="float-right">Delete</a>
					<a data-toggle="modal" style="margin-right: 10px" data-id="<?php echo e($comment->id); ?>" 
					title="edit" class="float-right editComment">Edit</a>
				</div>
			</li>			
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<hr>

	<?php if(Auth::check()): ?>
		<div class="card">
			<div class="card-block" style="padding: 20px 20px">
				<form method="POST" action="/posts/<?php echo e($post->id); ?>/comments/<?php echo e(Auth::user()->id); ?>">
					<?php echo e(csrf_field()); ?>

					<input type="text" id="user" name="userId" value="<?php echo e(Auth::user()->id); ?>" hidden>
					<div class="form-group">
						<textarea class="form-control" name="body" id="comment" placeholder="Your comment here" required></textarea>
					</div>

					<div class="form-group">
						<button class="btn btn-primary" type="submit">Add Comment</button>
					</div>
				</form>

				<?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
		</div>
	<?php endif; ?>	

	<?php echo $__env->make('layouts.comment-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script src="<?php echo e(asset('js/master.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>