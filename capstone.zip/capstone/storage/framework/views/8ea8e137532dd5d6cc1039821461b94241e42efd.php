<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Save Our School</title>

  <!-- Bootstrap core CSS -->
  <link href="<?php echo e(asset('js/landing/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">

  <!-- google font -->
 <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="<?php echo e(asset('css/landing/business-casual.css')); ?>" rel="stylesheet">

  <!-- font awesome -->
  <link href="<?php echo e(asset('js/landing/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">

</head>