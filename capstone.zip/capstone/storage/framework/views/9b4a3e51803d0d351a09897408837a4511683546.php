<!DOCTYPE html>
<html lang="en">

	<?php echo $__env->make('layouts.landing.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('extrahead'); ?>;

	<body>
     	<?php if($flash = session('message')): ?>
	      <div id="flash-message" class="alert alert-success" role="alert">
	        <?php echo e($flash); ?>

	      </div>
	     <?php endif; ?>
		<?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<?php echo $__env->make('layouts.landing.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldContent('content'); ?>

		<?php echo $__env->make('layouts.landing.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<?php echo $__env->make('layouts.landing.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->make('layouts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldContent('scripts'); ?>

	</body>
</html>