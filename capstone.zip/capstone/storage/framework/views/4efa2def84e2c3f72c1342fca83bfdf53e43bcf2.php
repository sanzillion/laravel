	<?php if(count($errors )): ?>
	<div id="flash-message" class="error-report">
		<div class="alert alert-primary">
		<h1><i class="fa fa-exclamation-triangle"></i>&nbsp Errors</h1>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	</div>
	<?php endif; ?>

	<?php if(session('error')): ?>
		<div class="alert alert-danger">
			<?php echo e(session('error')); ?>

		</div>
	<?php endif; ?>
