<div class="blog-masthead">
  <div class="container">
    <nav class="nav">
      <a class="nav-link" href="/">Home</a>
      <?php if(!Auth::check()): ?>
        <a class="nav-link" href="/login">Login</a>
        <a class="nav-link" href="/apply">Register</a>
        <a class="nav-link ml-auto" href="/admin/login">Admin</a>
      <?php endif; ?>

      <?php if(Auth::check()): ?>

        <?php if(Auth::guard('web')->check()): ?>
          <a class="nav-link" href="/posts/create">Create Post</a>
        <?php elseif(Auth::guard('admin')->check()): ?>
          <?php if(Auth::id() == 1): ?>
            <a class="nav-link" href="/master">Dashboard</a>
          <?php else: ?>
            <a class="nav-link" href="/admin">Dashboard</a>
          <?php endif; ?>
        <?php endif; ?>

        <a class="nav-link" href="<?php echo e($url); ?>">Logout</a>
        <a class="nav-link ml-auto" href="#"><?php echo e(Auth::user()->name); ?></a>
      <?php endif; ?>
      
    </nav>
  </div>
</div>