<!DOCTYPE html>
<html lang="en">

  <?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <body>

	<?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php if($flash = session('message')): ?>
      <div id="flash-message" class="alert alert-success" role="alert">
        <?php echo e($flash); ?>

      </div>
    <?php endif; ?>

    <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container">

      <div class="row">

        <div class="col-sm-8 blog-main">
          <?php echo $__env->yieldContent('content'); ?>
        </div>

        <div class="col-sm-3 offset-sm-1 blog-sidebar">
          <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

      </div><!-- /.row -->

    </div><!-- /.container -->

	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php echo $__env->yieldContent('scripts'); ?>
  <?php echo $__env->make('layouts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  </body>
</html>
