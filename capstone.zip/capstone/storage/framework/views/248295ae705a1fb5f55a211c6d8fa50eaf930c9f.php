<?php $__env->startSection('content'); ?>

	<header class="page-header">
		<div class="container-fluid">
			<h2 class="no-margin-bottom">Manage Blog Posts</h2>
		</div>
	</header>
	
	<?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="row incon">

	<div class="col-md-12 col-sm-12">
		<div class="card">

			<div class="container-fluid no-margin">
				<div class="row pad-top">
					<div class="col-md-12 col-sm-12">
						<h2><i class="fa fa-check-square-o"></i>&nbsp Pending Approval</h2>
					</div>
				</div> 
			</div>

			<table class="table table-sm pendingTable">
				  <thead class="thead-inverse">
				    <tr>
				      <th>#</th>
				      <th>User</th>
				      <th>Title</th>
				      <th>Body</th>
				      <th>Date</th>
				      <th>Time</th>
				      <th>Options</th>
				    </tr>
				  </thead>
			  <tbody class="pending">
				  	<?php if(count($pendings) > 0): ?>
				  	<?php $__currentLoopData = $pendings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    <tr>
					      <th scope="row"><?php echo e($pending->id); ?></th>
					      <td><?php echo e($pending->user->name); ?></td>
					      <td><?php echo substr($pending->title, 0, 10).'...'; ?></td>
					      <td><?php echo substr($pending->body, 0, 20).'...'; ?></td>
					      <td><?php echo e($pending->created_at->toFormattedDateString()); ?></td>
					      <td><?php echo e($pending->created_at->toFormattedDateString()); ?></td>
					      <td>

							<a class='btn btn-info btn-sm float-left view text-white' 
							style='margin-right: 5px;' data-id='<?php echo e($pending->id); ?>'>
					      		<i class='fa fa-window-maximize'></i>
					      	</a>

							<a class="btn btn-success btn-sm float-left accept" style="margin-right: 5px;" href="/approve/<?php echo e($pending->id); ?>">
			                    <i class="fa fa-plus-circle"></i>
		    	            </a>

					      	<?php echo e(Form::open(['action' => ['PendingController@destroy', $pending->id], 'method' => 'POST', 'class' => 'float-left'])); ?>

								<?php echo e(Form::hidden('_method', 'DELETE')); ?>

								<?php echo e(Form::button('<i class="fa fa-thumbs-down"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-sm'])); ?>

							<?php echo e(Form::close()); ?>


					      </td>
					    </tr>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    <?php else: ?>
				    	<tr>
				    		<th colspan="7"></th>
				    	</tr>
				    	<tr>
				    		<th colspan="7" class="text-center">
				    			<h3>No entry</h3>
				    		</th>
				    	</tr>
				    <?php endif; ?>
				  </tbody>
			</table>

			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<?php echo e($pendings->render()); ?>

					</div>
				</div>
			</div>
		</div>
		
	</div>
	
	
	<div class="col-md-12 col-sm-12">
		<div class="card">
		
			<div class="container-fluid no-margin">
				<div class="row pad-top">
					<div class="col-md-6 col-sm-6">
						<h2><i class="fa fa-book"></i>&nbsp Blog Posts &nbsp
							<?php if(auth()->user()->isMaster()): ?>
								<button type="button" class="btn btn-danger btn-sm deleteAllPosts">
								  <i class="fa fa-exclamation-triangle icon"></i>
								</button>
							<?php endif; ?>
						</h2>
					</div>
					<div class="col-md-6">
						<div class="form-group float-right">
						  <div class="input-group mb-2 mr-sm-2 mb-sm-0" style="height: 25px;">
						    <div class="input-group-addon"><i class="fa fa-search" style="font-size: 10px;"></i></div>
						    <input type="text" class="form-control form-control-sm searchPost" placeholder="search">
						  </div>
						</div>
					</div>
				</div> 
			</div>

			<table class="table table-sm">
			  <thead class="thead-inverse">
			    <tr>
			      <th>#</th>
			      <th>User</th>
			      <th>Title</th>
			      <th>Body</th>
			      <th>Created</th>
			      <th>Updated</th>
			      <th>Option</th>
			    </tr>
			  </thead>
			  <tbody class="posts">

			  </tbody>
			</table>
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<button class="btn btn-default btn-sm back">
							<i class="fa fa-backward"></i>&nbsp Previous
						</button>
						<button class="btn btn-default btn-sm for">
							Next &nbsp<i class="fa fa-forward"></i>
						</button>
						
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>

	<?php $__env->startComponent('layouts.dashboard.modal'); ?>
		<?php $__env->slot('id'); ?>
			showPost
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('title'); ?>
			<div class="text-info post-user">
				
			</div>
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('modalBody'); ?>	
		<div class="row">
			<div class="col-md-10 offset-md-1">

		        <div class="card">
		        	<h3 class="card-header"></h3>
					  <div class="card-body">
					    <p class="card-text text-justify text-sm">
					    </p>
					  </div>
				</div>

			</div>
		</div>

		<div class="text-center">
			<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		</div>
			
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('modalFooter'); ?>
		<?php $__env->endSlot(); ?>
	<?php echo $__env->renderComponent(); ?>

	<?php $__env->startComponent('layouts.dashboard.sm-modal'); ?>
		<?php $__env->slot('id'); ?>
			deletePost
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('title'); ?>
			<i class="fa fa-asterisk text-danger"></i> You are about to delete a blog post. Are you sure?
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('modalBody'); ?>	
			<div class="row">
				<div class="col-md-12 col-sm-12">
					<?php echo e(Form::open(['action' => ['PostsController@destroy', ''], 'method' => 'POST', 'class' => 'float-left', 'id' => 'postDelete'])); ?>

						<?php echo e(Form::hidden('_method', 'DELETE')); ?>

						<?php echo e(Form::button('Yes', ['type' => 'submit', 'class' => 'btn btn-danger'])); ?>

						<button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
					<?php echo e(Form::close()); ?>

				</div>
			</div>
	      	
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('modalFooter'); ?>
		<?php $__env->endSlot(); ?>
	<?php echo $__env->renderComponent(); ?>
	
	<?php $__env->startComponent('layouts.dashboard.modal'); ?>
		<?php $__env->slot('id'); ?>
			deleteAllPosts
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('title'); ?>
			<i class="fa fa-asterisk text-danger"></i> Proceed with caution!
			Do you want to delete ALL Posts? Are you sure?
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('modalBody'); ?>	
		<div class="row">
				<div class="col-md-12 col-sm-12">
					<form action="/blog/deleteAll" method="POST">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<button class="btn btn-danger" type="submit">Yes</button>
						<button type="button" class="btn btn-secondary no" data-dismiss="modal">No</button>
					</form>
					
						
					
				</div>
			</div>
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('modalFooter'); ?>
		<?php $__env->endSlot(); ?>
	<?php echo $__env->renderComponent(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script src="<?php echo e(asset('js/master.js')); ?>"></script>
	<script src="<?php echo e(asset('js/admin/blog.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>