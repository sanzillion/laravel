  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Capstone</title>

    <!-- Bootstrap core CSS -->


    <!-- Custom styles for this template -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
  </head>