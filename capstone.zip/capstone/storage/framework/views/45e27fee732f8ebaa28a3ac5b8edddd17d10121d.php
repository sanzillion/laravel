  <div class="blog-post">
  	<a href="/posts/<?php echo e($post->id); ?>">
    	<h2 class="blog-post-title"><?php echo e($post->title); ?></h2>
  	</a>
    <p class="blog-post-meta">
    <?php echo e($post->created_at->toFormattedDateString()); ?> 
    by <?php echo e($post->user->name); ?></p>
    
    <div class="text-justify">
    	<p><?php echo $post->body; ?></p>
    </div>

  </div><!-- /.blog-post -->