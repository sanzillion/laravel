<?php

namespace App;

class Sms extends Model
{
    //
}
