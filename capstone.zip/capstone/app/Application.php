<?php

namespace App;

class Application extends Model
{
    protected $table = 'pending_users';
}
