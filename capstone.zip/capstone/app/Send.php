<?php

namespace App;

class Send extends Model
{
    protected $table = 'ship';
}
