<footer class="bg-faded text-center py-5">
  <div class="container">
    <p class="m-0">© 2017 Save Our School Network</p>
  </div>
</footer>