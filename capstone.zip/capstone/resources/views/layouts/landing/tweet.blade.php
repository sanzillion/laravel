<div class="bg-faded p-4 my-4" id="mission">
	<div class="hr-sect">
	    <h2 class="text-center text-lg text-uppercase my-0 text-danger">
	    <b>Latest Tweet</b>
	    </h2>
	</div>
	<p class="qt-mission">“The HeartCry Missionary Society exists to glorify God through the establishment of biblical
	churches by equipping and mobilizing indigenous churches and missionaries in the least
	evangelized areas of the world.”</p>
</div>