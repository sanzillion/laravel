<html>
	<body>
		<h1>Welcome to SOS, {{ $user->name }}</h1>
	</body>
</html>